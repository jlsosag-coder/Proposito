// ── Data ──────────────────────────────────────────────────────────────
const steps = [
  {
    num: "Herramienta 1",
    title: "Las tres voces",
    desc: "Antes de encontrar tu propósito, necesitas identificar qué voces estás escuchando. Hay tres voces que compiten por dirigir tu vida.",
    insight: "La mayoría vivimos respondiendo a las dos primeras voces sin saberlo. Tu propósito vive en la tercera — la más callada, pero la más verdadera.",
    questions: [
      { label: "Voz 1 — El guión heredado", text: "¿Qué frases o creencias heredadas de tu familia o cultura guían tus decisiones hoy, aunque no las hayas elegido conscientemente?", hint: "Ej: «hay que ser responsable», «no puedes vivir de eso», «así se hacen las cosas».", key: "v1" },
      { label: "Voz 2 — El miedo social", text: "¿Qué decisiones has tomado principalmente para ser aprobado o para no decepcionar a alguien?", hint: "Piensa en tu carrera, relaciones o estilo de vida.", key: "v2" },
      { label: "Voz 3 — Tu voz real", text: "¿Cuándo fue la última vez que sentiste que estabas siendo completamente tú mismo? ¿Qué estabas haciendo?", hint: "No importa si fue algo pequeño. Ese momento es una señal.", key: "v3" }
    ]
  },
  {
    num: "Herramienta 2",
    title: "Arqueología de vida",
    desc: "Tu propósito dejó huellas a lo largo de toda tu historia. Esta herramienta te ayuda a rastrearlas y encontrar el patrón que las une.",
    insight: "No construyes tu propósito desde cero. Lo excavas. Ya estuvo ahí toda tu vida — en ciertos momentos de máxima energía y conexión.",
    questions: [
      { label: "Momentos de máxima energía", text: "¿En qué momentos de tu vida sentiste que el tiempo desaparecía? ¿Cuándo te sentiste completamente vivo haciendo algo?", hint: "Pueden ser de cualquier época — infancia, adolescencia, o reciente. Escribe 2 o 3 momentos.", key: "arq1" },
      { label: "Momentos de máxima conexión", text: "¿Cuándo sentiste que lo que hacías realmente importaba? ¿Cuándo tuviste la sensación de estar exactamente donde debías estar?", hint: "Piensa en momentos donde tocaste algo verdadero en otra persona.", key: "arq2" },
      { label: "El patrón oculto", text: "Mirando esos momentos juntos, ¿qué hilo común ves? ¿Qué estabas haciendo en todos ellos, aunque el contexto fuera diferente?", hint: "Puede ser: enseñar, resolver, crear, conectar, liderar, construir, sanar...", key: "arq3" }
    ]
  },
  {
    num: "Herramienta 3",
    title: "El triángulo de propósito",
    desc: "Tu propósito vive en el cruce exacto de tres elementos. Si falta uno, algo siempre se sentirá incompleto.",
    insight: "La mayoría vive en uno o dos vértices. El propósito verdadero requiere los tres al mismo tiempo.",
    questions: [
      { label: "Vértice 1 — Talento natural", text: "¿Qué haces de forma casi automática que para otros resulta difícil o especial? ¿Qué te pide la gente que repitas o expliques?", hint: "Lo que te sale solo, lo que no te cuesta como a otros, aunque tú lo veas como «normal».", key: "tri1" },
      { label: "Vértice 2 — Pasión profunda", text: "¿Por qué causa o transformación estarías dispuesto a sacrificar algo importante, incluso si nadie te viera ni te pagara?", hint: "No lo que te gusta — lo que te mueve visceralmente. Lo que defiendes.", key: "tri2" },
      { label: "Vértice 3 — Impacto en otros", text: "¿Qué cambia en una persona después de estar contigo o de recibir lo que tú das? ¿Quién es diferente y cómo?", hint: "Sé específico. «Todos» no es una respuesta. Piensa en una persona concreta.", key: "tri3" }
    ]
  },
  {
    num: "Herramienta 4",
    title: "La prueba del legado",
    desc: "Cuando te mueves mentalmente al final de tu vida y miras hacia atrás, todo el ruido desaparece. Lo que queda es lo único que de verdad importó.",
    insight: "El arrepentimiento anticipado es la brújula más honesta que existe. Lo que más temes no haber hecho es casi siempre lo que más debes hacer.",
    questions: [
      { label: "El funeral", text: "¿Qué quieres que digan de ti las personas más importantes de tu vida el día de tu funeral?", hint: "No tus logros ni títulos. Quién fuiste para ellos.", key: "leg1" },
      { label: "La huella", text: "¿Qué habrá cambiado en el mundo — aunque sea en tu mundo pequeño — por el hecho de que tú exististe?", hint: "Puede ser una persona, una familia, una comunidad. Algo concreto.", key: "leg2" },
      { label: "El arrepentimiento", text: "Si llegaras al final de tu vida sin haber vivido tu propósito, ¿de qué específicamente te arrepentirías?", hint: "Responde sin filtro. Esta es la pregunta más poderosa del proceso.", key: "leg3" }
    ]
  },
  {
    num: "Herramienta 5",
    title: "Tu declaración de propósito",
    desc: "Ahora integras todo en una sola frase que capture quién eres y para qué estás aquí. No busques la perfección — busca la honestidad.",
    insight: "Esta frase no es un slogan. Es una brújula. Cuando tengas que elegir entre dos caminos, ella te dice cuál tomar.",
    questions: [
      { label: "Tu talento en acción", text: "Completa: «Soy alguien que...» (describe lo que haces de forma natural, no tu profesión)", hint: "Ej: «conecta ideas», «abre espacios seguros», «simplifica lo complejo», «despierta potencial».", key: "dec1" },
      { label: "La transformación que produces", text: "Completa: «...para que...» (describe el cambio que produces en otros)", hint: "Ej: «las personas se vean a sí mismas», «nadie tenga que caminar solo», «el conocimiento llegue a quien lo necesita».", key: "dec2" },
      { label: "Tu persona específica", text: "Completa: «...en...» (describe a quién específicamente)", hint: "No «todos». Una persona concreta: «personas que sienten que viven la vida de otros», «jóvenes sin dirección», «líderes abrumados».", key: "dec3" }
    ]
  }
];

// ── State ─────────────────────────────────────────────────────────────
let current = 0;
const answers = {};
let userName = '';

function loadState() {
  try {
    const saved = sessionStorage.getItem('proposito_state');
    if (saved) {
      const state = JSON.parse(saved);
      current = state.current || 0;
      userName = state.userName || '';
      Object.assign(answers, state.answers || {});
    }
  } catch(e) {}
}

function saveState() {
  try {
    sessionStorage.setItem('proposito_state', JSON.stringify({ current, userName, answers }));
  } catch(e) {}
}

// ── Welcome screen ─────────────────────────────────────────────────────
function buildWelcome() {
  document.getElementById('navBar').classList.add('hidden');
  const container = document.getElementById('stepsContainer');
  container.innerHTML = `
    <div class="step-card" style="margin-top:20px;">
      <div class="step-header">
        <p class="step-num">Bienvenido</p>
        <h2 class="step-title">Antes de comenzar</h2>
        <p class="step-desc">Este proceso te guiará a través de cinco herramientas para descubrir tu propósito personal. Al finalizar podrás descargar un PDF con todo tu trabajo.</p>
      </div>
      <div class="step-body">
        <div class="insight"><strong>Tiempo estimado:</strong> 30 a 60 minutos. Responde con honestidad y sin filtro — nadie más verá tus respuestas a menos que tú lo decidas.</div>
        <div class="q-block">
          <p class="q-label">Tu nombre</p>
          <p class="q-text">¿Cómo te llamas?</p>
          <p class="q-hint">Aparecerá en tu PDF al finalizar el proceso.</p>
          <input
            type="text"
            id="nameInput"
            placeholder="Escribe tu nombre aquí..."
            oninput="onNameInput()"
            autocomplete="given-name"
            value="${escapeHtml(userName)}"
          />
        </div>
      </div>
    </div>
  `;

  // Show start button
  document.getElementById('navBar').classList.remove('hidden');
  const btnBack = document.getElementById('btnBack');
  const btnNext = document.getElementById('btnNext');
  btnBack.style.display = 'none';
  btnNext.textContent = 'Comenzar →';
  btnNext.disabled = userName.trim().length < 2;
  btnNext.onclick = startProcess;

  // Dots for welcome
  const wrap = document.getElementById('progressDots');
  wrap.innerHTML = '';
  document.getElementById('progressLabel').textContent = 'Proceso de propósito';
}

function onNameInput() {
  const val = document.getElementById('nameInput')?.value?.trim() || '';
  userName = val;
  document.getElementById('btnNext').disabled = val.length < 2;
  saveState();
}

function startProcess() {
  userName = document.getElementById('nameInput')?.value?.trim() || userName;
  saveState();
  current = 0;
  document.getElementById('btnNext').textContent = 'Continuar';
  document.getElementById('btnNext').onclick = goNext;
  buildStep(current);
  buildDots();
  updateBackBtn();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── DOM builders ──────────────────────────────────────────────────────
function buildDots() {
  const wrap = document.getElementById('progressDots');
  wrap.innerHTML = '';
  steps.forEach((_, i) => {
    const d = document.createElement('div');
    d.className = 'progress-dot' + (i < current ? ' done' : i === current ? ' active' : '');
    wrap.appendChild(d);
  });
  const label = current >= steps.length
    ? 'Proceso completo ✓'
    : `Herramienta ${current + 1} de ${steps.length}`;
  document.getElementById('progressLabel').textContent = label;
}

function buildStep(idx) {
  const s = steps[idx];
  const container = document.getElementById('stepsContainer');
  container.innerHTML = '';
  document.getElementById('navBar').classList.remove('hidden');

  const card = document.createElement('div');
  card.className = 'step-card';

  const qs = s.questions.map(q => `
    <div class="q-block">
      <p class="q-label">${q.label}</p>
      <p class="q-text">${q.text}</p>
      <p class="q-hint">${q.hint}</p>
      <textarea id="${q.key}" placeholder="Escribe aquí tu respuesta..." oninput="onTextInput()" rows="4">${escapeHtml(answers[q.key] || '')}</textarea>
    </div>
    <div class="divider"></div>
  `).join('');

  card.innerHTML = `
    <div class="step-header">
      <p class="step-num">${s.num}</p>
      <h2 class="step-title">${s.title}</h2>
      <p class="step-desc">${s.desc}</p>
    </div>
    <div class="step-body">
      <div class="insight"><strong>¿Por qué esta herramienta?</strong> ${s.insight}</div>
      ${qs}
    </div>
  `;
  container.appendChild(card);
  checkAnswers();
}

function buildResult() {
  const container = document.getElementById('stepsContainer');
  document.getElementById('navBar').classList.add('hidden');

  const t  = answers.dec1 || '[tu talento]';
  const tr = answers.dec2 || '[tu transformación]';
  const p  = answers.dec3 || '[tu persona]';
  const purpose = `Soy alguien que ${t} para que ${tr} en ${p}.`;
  const name = userName || 'tú';

  container.innerHTML = `
    <div class="result-card">
      <p class="result-eyebrow">Declaración de propósito vivido</p>
      <p style="font-size:13px;color:rgba(255,255,255,.55);margin-bottom:14px;font-weight:500;letter-spacing:.02em;">${escapeHtml(name)}</p>
      <div class="result-quote-mark">"</div>
      <p class="result-purpose">${escapeHtml(purpose)}</p>

      <div class="result-divider"></div>

      <div class="result-section">
        <p class="result-section-label">Tu patrón de vida</p>
        <p class="result-section-text">${escapeHtml(answers.arq3 || answers.tri1 || '—')}</p>
      </div>
      <div class="result-section">
        <p class="result-section-label">Tu pasión profunda</p>
        <p class="result-section-text">${escapeHtml(answers.tri2 || '—')}</p>
      </div>
      <div class="result-section">
        <p class="result-section-label">Tu mayor arrepentimiento anticipado</p>
        <p class="result-section-text">${escapeHtml(answers.leg3 || '—')}</p>
      </div>

      <div class="result-divider"></div>

      <div class="validation">
        <p class="validation-title">Tres pruebas para tu declaración</p>
        <div class="val-item"><span class="val-dot"></span>¿Te incomoda un poco? Si es completamente cómoda, es demasiado segura.</div>
        <div class="val-item"><span class="val-dot"></span>¿La reconoces como tuya? ¿Sientes que alguien por fin nombró algo que ya sabías?</div>
        <div class="val-item"><span class="val-dot"></span>¿Te da dirección en decisiones concretas? ¿Te dice qué hacer el martes por la mañana?</div>
      </div>

      <div class="result-actions">
        <button class="btn-pdf" onclick="downloadPDF()">⬇ Descargar mi PDF</button>
        <button class="btn-share" onclick="shareResult('${escapeAttr(purpose)}')">📤 Compartir mi propósito</button>
        <button class="btn-restart" onclick="restart()">Volver al inicio</button>
      </div>
    </div>

    <div class="result-note">
      <p class="result-note-label">Recuerda</p>
      <p class="result-note-text">Esta es tu primera versión. No es perfecta — y no debe serlo. Se llama propósito <em>vivido</em> porque se afina con el tiempo, en las decisiones reales de cada día.</p>
    </div>
  `;
}

// ── PDF Generator ─────────────────────────────────────────────────────
function downloadPDF() {
  if (typeof window.jspdf === 'undefined') {
    alert('Cargando generador de PDF, intenta de nuevo en un momento...');
    return;
  }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const AZUL   = [68, 93, 123];
  const LIMA   = [178, 210, 53];
  const BLANCO = [255, 255, 255];
  const GRIS   = [121, 137, 163];
  const TEXTO  = [26, 35, 50];
  const TEXTO2 = [55, 65, 81];
  const BGPAGE = [245, 247, 250];

  const W = 210;
  const M = 18; // margin
  const CW = W - M * 2; // content width
  const name = userName || '';
  const purpose = `Soy alguien que ${answers.dec1 || '...'} para que ${answers.dec2 || '...'} en ${answers.dec3 || '...'}.`;
  const date = new Date().toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' });

  // ── Helper: wrapped text returning new Y ──
  function addText(text, x, y, opts = {}) {
    const { size = 10, color = TEXTO2, weight = 'normal', maxW = CW, lineH = 6 } = opts;
    doc.setFontSize(size);
    doc.setTextColor(...color);
    doc.setFont('helvetica', weight);
    const lines = doc.splitTextToSize(String(text || '—'), maxW);
    lines.forEach((line, i) => doc.text(line, x, y + i * lineH));
    return y + lines.length * lineH;
  }

  function sectionLabel(text, x, y) {
    doc.setFontSize(8);
    doc.setTextColor(...GRIS);
    doc.setFont('helvetica', 'bold');
    doc.text(text.toUpperCase(), x, y);
    return y + 5;
  }

  function hRule(y, color = [220, 225, 232]) {
    doc.setDrawColor(...color);
    doc.setLineWidth(0.3);
    doc.line(M, y, W - M, y);
    return y + 4;
  }

  // ════════════════════════════════════════
  // PAGE 1 — PORTADA + DECLARACIÓN
  // ════════════════════════════════════════

  // Header block — azul
  doc.setFillColor(...AZUL);
  doc.rect(0, 0, W, 68, 'F');

  // Accent bar
  doc.setFillColor(...LIMA);
  doc.rect(0, 0, 4, 68, 'F');

  // Eyebrow
  doc.setFontSize(8);
  doc.setTextColor(...LIMA);
  doc.setFont('helvetica', 'bold');
  doc.text('PROCESO DE PROPÓSITO', M + 2, 18);

  // Main title
  doc.setFontSize(22);
  doc.setTextColor(...BLANCO);
  doc.setFont('helvetica', 'bold');
  doc.text('Descubre tu', M + 2, 30);
  doc.text('Llamado Personal', M + 2, 41);

  // Name + date
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'normal');
  doc.text(name, M + 2, 54);
  doc.setFontSize(8);
  doc.setTextColor(...LIMA);
  doc.text(date, M + 2, 61);

  // ── Declaración box ──
  let y = 80;
  doc.setFillColor(...AZUL);
  doc.roundedRect(M, y, CW, 52, 3, 3, 'F');

  doc.setFontSize(7.5);
  doc.setTextColor(...LIMA);
  doc.setFont('helvetica', 'bold');
  doc.text('TU DECLARACIÓN DE PROPÓSITO VIVIDO', M + 6, y + 9);

  // Big quote mark
  doc.setFontSize(32);
  doc.setTextColor(...LIMA);
  doc.setFont('helvetica', 'bold');
  doc.text('"', M + 6, y + 20);

  // Purpose text
  doc.setFontSize(11);
  doc.setTextColor(...BLANCO);
  doc.setFont('helvetica', 'bold');
  const purposeLines = doc.splitTextToSize(purpose, CW - 14);
  purposeLines.forEach((line, i) => doc.text(line, M + 6, y + 26 + i * 7));

  y = 144;

  // ── Summary grid ──
  const col2x = M + CW / 2 + 4;
  const colW  = CW / 2 - 6;

  const summaryItems = [
    { label: 'Tu patrón de vida',             value: answers.arq3 || answers.tri1 },
    { label: 'Tu pasión profunda',             value: answers.tri2 },
    { label: 'Tu impacto en otros',            value: answers.tri3 },
    { label: 'Tu mayor arrepentimiento ant.', value: answers.leg3 },
  ];

  summaryItems.forEach((item, idx) => {
    const cx = idx % 2 === 0 ? M : col2x;
    const cy = y + Math.floor(idx / 2) * 28;
    doc.setFillColor(...BGPAGE);
    doc.roundedRect(cx, cy, colW, 24, 2, 2, 'F');
    doc.setFontSize(7);
    doc.setTextColor(...GRIS);
    doc.setFont('helvetica', 'bold');
    doc.text(item.label.toUpperCase(), cx + 5, cy + 7);
    doc.setFontSize(9);
    doc.setTextColor(...TEXTO);
    doc.setFont('helvetica', 'normal');
    const vlines = doc.splitTextToSize(item.value || '—', colW - 10);
    vlines.slice(0, 2).forEach((l, li) => doc.text(l, cx + 5, cy + 14 + li * 5));
  });

  y += 60;

  // ── Tres pruebas ──
  y = hRule(y);
  doc.setFontSize(8);
  doc.setTextColor(...AZUL);
  doc.setFont('helvetica', 'bold');
  doc.text('TRES PRUEBAS PARA TU DECLARACIÓN', M, y);
  y += 6;

  const pruebas = [
    '¿Te incomoda un poco? Si es completamente cómoda, es demasiado segura.',
    '¿La reconoces como tuya? ¿Sientes que alguien por fin nombró algo que ya sabías?',
    '¿Te da dirección en decisiones concretas? ¿Te dice qué hacer el martes por la mañana?'
  ];
  pruebas.forEach(p => {
    doc.setFillColor(...LIMA);
    doc.circle(M + 2, y - 1.5, 1.2, 'F');
    doc.setFontSize(9);
    doc.setTextColor(...TEXTO2);
    doc.setFont('helvetica', 'normal');
    const plines = doc.splitTextToSize(p, CW - 8);
    plines.forEach((l, li) => doc.text(l, M + 6, y + li * 5));
    y += plines.length * 5 + 3;
  });

  // Footer p1
  doc.setFillColor(...AZUL);
  doc.rect(0, 285, W, 12, 'F');
  doc.setFontSize(7.5);
  doc.setTextColor(...LIMA);
  doc.setFont('helvetica', 'bold');
  doc.text('1', W / 2, 292, { align: 'center' });

  // ════════════════════════════════════════
  // PAGES 2–6 — ONE PER HERRAMIENTA
  // ════════════════════════════════════════

  steps.forEach((step, si) => {
    doc.addPage();

    // Header strip
    doc.setFillColor(...AZUL);
    doc.rect(0, 0, W, 28, 'F');
    doc.setFillColor(...LIMA);
    doc.rect(0, 0, 4, 28, 'F');

    doc.setFontSize(8);
    doc.setTextColor(...LIMA);
    doc.setFont('helvetica', 'bold');
    doc.text(step.num.toUpperCase(), M + 2, 11);

    doc.setFontSize(14);
    doc.setTextColor(...BLANCO);
    doc.setFont('helvetica', 'bold');
    doc.text(step.title, M + 2, 21);

    // Insight box
    let py = 36;
    doc.setFillColor(240, 242, 245);
    doc.setDrawColor(...LIMA);
    doc.setLineWidth(0.8);
    doc.line(M, py, M, py + 16);
    doc.setFontSize(8.5);
    doc.setTextColor(...TEXTO2);
    doc.setFont('helvetica', 'italic');
    const ilines = doc.splitTextToSize(step.insight, CW - 8);
    ilines.slice(0, 3).forEach((l, li) => doc.text(l, M + 4, py + 5 + li * 5.5));
    py += Math.max(18, ilines.length * 5.5 + 6);

    // Questions
    step.questions.forEach((q, qi) => {
      if (py > 260) { doc.addPage(); py = 20; }

      // Question label
      doc.setFontSize(7.5);
      doc.setTextColor(...GRIS);
      doc.setFont('helvetica', 'bold');
      doc.text(q.label.toUpperCase(), M, py);
      py += 5;

      // Question text
      doc.setFontSize(9.5);
      doc.setTextColor(...TEXTO);
      doc.setFont('helvetica', 'bold');
      const qtlines = doc.splitTextToSize(q.text, CW);
      qtlines.forEach((l, li) => doc.text(l, M, py + li * 5.5));
      py += qtlines.length * 5.5 + 2;

      // Answer box
      const answer = answers[q.key] || '';
      const alines = doc.splitTextToSize(answer || '—', CW - 10);
      const boxH = Math.max(18, alines.length * 5.5 + 10);

      doc.setFillColor(...BGPAGE);
      doc.setDrawColor(221, 225, 232);
      doc.setLineWidth(0.3);
      doc.roundedRect(M, py, CW, boxH, 2, 2, 'FD');

      doc.setFontSize(9.5);
      doc.setTextColor(answer ? TEXTO[0] : 160, answer ? TEXTO[1] : 160, answer ? TEXTO[2] : 160);
      doc.setFont('helvetica', 'normal');
      alines.forEach((l, li) => doc.text(l, M + 5, py + 7 + li * 5.5));
      py += boxH + 8;

      // Divider between questions
      if (qi < step.questions.length - 1) {
        doc.setDrawColor(221, 225, 232);
        doc.setLineWidth(0.2);
        doc.line(M, py - 3, W - M, py - 3);
      }
    });

    // Footer
    doc.setFillColor(...AZUL);
    doc.rect(0, 285, W, 12, 'F');
    doc.setFontSize(7.5);
    doc.setTextColor(...LIMA);
    doc.setFont('helvetica', 'bold');
    doc.text(String(si + 2), W / 2, 292, { align: 'center' });
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'normal');
    doc.text(name, M, 292);
    doc.text(step.title, W - M, 292, { align: 'right' });
  });

  // ── Save ──
  const filename = `proposito-${(name || 'mi').toLowerCase().replace(/\s+/g, '-')}.pdf`;
  doc.save(filename);
}

// ── Helpers ───────────────────────────────────────────────────────────
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escapeAttr(str) {
  return String(str || '').replace(/'/g,"\\'");
}

function onTextInput() {
  saveCurrentAnswers();
  checkAnswers();
  saveState();
}

function saveCurrentAnswers() {
  if (current >= steps.length) return;
  steps[current].questions.forEach(q => {
    const el = document.getElementById(q.key);
    if (el) answers[q.key] = el.value.trim();
  });
}

function checkAnswers() {
  if (current >= steps.length) return;
  const allFilled = steps[current].questions.every(q => {
    const el = document.getElementById(q.key);
    return el && el.value.trim().length > 4;
  });
  document.getElementById('btnNext').disabled = !allFilled;
}

function goNext() {
  saveCurrentAnswers();
  saveState();
  current++;
  if (current >= steps.length) {
    buildResult();
    buildDots();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  buildStep(current);
  buildDots();
  updateBackBtn();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBack() {
  if (current <= 0) return;
  saveCurrentAnswers();
  current--;
  buildStep(current);
  buildDots();
  updateBackBtn();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateBackBtn() {
  const btn = document.getElementById('btnBack');
  if (btn) btn.style.display = current === 0 ? 'none' : '';
}

function restart() {
  current = 0;
  userName = '';
  Object.keys(answers).forEach(k => delete answers[k]);
  try { sessionStorage.removeItem('proposito_state'); } catch(e) {}
  document.getElementById('navBar').classList.remove('hidden');
  buildWelcome();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function shareResult(purpose) {
  if (navigator.share) {
    navigator.share({ title: 'Mi propósito de vida', text: purpose }).catch(() => {});
  } else {
    navigator.clipboard.writeText(purpose)
      .then(() => alert('¡Declaración copiada al portapapeles!'))
      .catch(() => alert(purpose));
  }
}

// ── PWA install prompt ────────────────────────────────────────────────
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredPrompt = e;
  document.getElementById('installBanner')?.classList.remove('hidden');
});
document.getElementById('installBtn')?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  document.getElementById('installBanner')?.classList.add('hidden');
});
window.addEventListener('appinstalled', () => {
  document.getElementById('installBanner')?.classList.add('hidden');
});

// ── Service Worker ────────────────────────────────────────────────────
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

// ── Init ──────────────────────────────────────────────────────────────
loadState();

if (userName && current > 0) {
  // Returning user mid-process
  buildStep(current);
  buildDots();
  updateBackBtn();
  document.getElementById('btnNext').onclick = goNext;
  document.getElementById('btnNext').textContent = 'Continuar';
} else if (current >= steps.length && userName) {
  buildResult();
  buildDots();
  document.getElementById('navBar').classList.add('hidden');
} else {
  buildWelcome();
}
